#define _GNU_SOURCE
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sched.h>

void *runner(void *p){
	int r,NPROC;
	NPROC = sysconf(_SC_NPROCESSORS_ONLN);//OBTEM O NUMERO DE CORES DO SISTEMA
	cpu_set_t cpu_set;//cria uma variavel do tipo cpu_set_t
        CPU_ZERO(&cpu_set); //inicializa a variavel sem informacao
    	    CPU_SET((int)(size_t)(int)(((size_t)p)%NPROC), &cpu_set);//adiciona uma cpu na lista
    	
    	

	r = sched_setaffinity(0, sizeof(cpu_set_t), &cpu_set);	//estabelece a afinidade
        
	//while(1)
	        printf("Esta é a execucao da Thread %d na CPU=%d; afinidade=%d\n", (int)(size_t) p, sched_getcpu(), r);

        pthread_exit(NULL);
}
int main(int argc, char *argv[]){
    
        int i, scope, r, NTHREADS,NPROC;
	
	NTHREADS = atoi(argv[1]);
    NPROC = sysconf(_SC_NPROCESSORS_ONLN);//OBTEM O NUMERO DE CORES DO SISTEMA
	printf("Numero de cores:%d\n", NPROC);

	pthread_t tid[NTHREADS];
        pthread_attr_t attr;
	pthread_attr_init(&attr);//inicializa a estrutura de atributos
        
	for(i=0;i<NTHREADS;i++)
			//if(i%2==0){
                pthread_create(&tid[i], &attr, runner, (void*)(size_t)i);
			//}

        for(i=0;i<NTHREADS;i++)
                pthread_join(tid[i], NULL);

	pthread_attr_destroy(&attr);//destroi a estrutura de atributos

        return 0;
}

