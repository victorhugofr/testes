#define _GNU_SOURCE
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sched.h>
int NTHREADS;
int *vA;
void *runner(void *p){
	int r,NPROC;
	NPROC = sysconf(_SC_NPROCESSORS_ONLN);//OBTEM O NUMERO DE CORES DO SISTEMA
	cpu_set_t cpu_set;//cria uma variavel do tipo cpu_set_t
        CPU_ZERO(&cpu_set); //inicializa a variavel sem informacao
    	    CPU_SET((int)(size_t)(int)(((size_t)p)%NPROC), &cpu_set);//adiciona uma cpu na lista
    	
    	

	r = sched_setaffinity(0, sizeof(cpu_set_t), &cpu_set);	//estabelece a afinidade
        
	//while(1)
	        printf("Esta é a execucao da Thread %d e a soma é: %d \n", (int)(size_t) p, vA[(int)(size_t) p]*vA[((int)(size_t) p)+1]);

        pthread_exit(NULL);
}
int main(int argc, char *argv[]){
    if(atoi(argv[1])%2 != 0 ){
    	printf("ERR:informe um numero par\n");
    	return 0;
    }
        int i, scope, r,NPROC;
	vA=(int*)malloc(NTHREADS*sizeof(int));
	NTHREADS = atoi(argv[1]);
    NPROC = sysconf(_SC_NPROCESSORS_ONLN);//OBTEM O NUMERO DE CORES DO SISTEMA
	printf("Numero de cores:%d\n", NPROC);
for(int i=0;i<NTHREADS;i++){
		vA[i]=rand() % 99;
}
for(int i=0;i<NTHREADS;i++){
		printf("vA[%d]  =  %d \n", i,vA[i]);
}

	pthread_t tid[NTHREADS/2];
        pthread_attr_t attr;
	pthread_attr_init(&attr);//inicializa a estrutura de atributos
        
	for(i=0;i<NTHREADS/2;i++)
                pthread_create(&tid[i], &attr, runner, (void*)(size_t)i);

        for(i=0;i<NTHREADS/2;i++)
                pthread_join(tid[i], NULL);

	pthread_attr_destroy(&attr);//destroi a estrutura de atributos

        return 0;
}

